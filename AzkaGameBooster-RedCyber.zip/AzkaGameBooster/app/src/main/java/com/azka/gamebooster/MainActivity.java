package com.azka.gamebooster;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private final int BG=Color.rgb(8,8,12), RED=Color.rgb(255,35,55), WHITE=Color.WHITE, MUTED=Color.rgb(160,160,170), PANEL=Color.rgb(22,22,29);
    private TextView status;
    @Override public void onCreate(Bundle b){super.onCreate(b); getWindow().setStatusBarColor(BG); getWindow().setNavigationBarColor(BG); build();}
    private void build(){
        ScrollView sc=new ScrollView(this); sc.setBackgroundColor(BG);
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(20),dp(24),dp(20),dp(28)); sc.addView(root);
        TextView crown=text("♛",26,RED,true); root.addView(crown);
        root.addView(text("AZKA",38,WHITE,true)); root.addView(text("GAME BOOSTER",19,RED,true));
        root.addView(text("PLAY SMOOTH  •  WIN MORE",11,MUTED,true),lp(0,5,0,20));
        status=cardText("●  GAMING MODE READY\nFPS stability tips enabled",15,Color.rgb(75,230,100),true); root.addView(status,lp(0,0,0,16));
        TextView boost=button("⚡  BOOST NOW",RED,WHITE,22); root.addView(boost,lp(0,0,0,14));
        boost.setOnClickListener(v->{status.setText("✓  BOOST CHECK COMPLETE\nClose unused apps • Keep device cool");Toast.makeText(this,"Optimasi aman selesai! Android tidak mengizinkan aplikasi ini memaksa FPS naik.",Toast.LENGTH_LONG).show();});
        TextView launch=button("🎮  LAUNCH MOBILE LEGENDS  ›",PANEL,WHITE,16); root.addView(launch,lp(0,0,0,22)); launch.setOnClickListener(v->openMl());
        root.addView(text("PERFORMANCE PANEL",16,WHITE,true),lp(0,0,0,12));
        LinearLayout stats=new LinearLayout(this); stats.setOrientation(LinearLayout.HORIZONTAL);
        stats.addView(stat("RAM","Android managed","▣"),new LinearLayout.LayoutParams(0,-2,1)); stats.addView(stat("TEMP","Check device","♨"),new LinearLayout.LayoutParams(0,-2,1)); root.addView(stats,lp(0,0,0,20));
        root.addView(text("QUICK OPTIMIZATION",16,WHITE,true),lp(0,0,0,12));
        tip(root,"01","GRAPHICS","Pilih Smooth dan frame rate tertinggi yang tersedia di MLBB.");
        tip(root,"02","COOLING","Berhenti sejenak jika HP terasa panas; hindari bermain sambil charging.");
        tip(root,"03","BACKGROUND","Tutup aplikasi yang tidak sedang digunakan.");
        tip(root,"04","STORAGE","Sisakan ruang penyimpanan agar sistem berjalan nyaman.");
        root.addView(text("Booster ini tidak mengubah file game, tidak mengakses RAM secara paksa, dan tidak menjanjikan FPS tambahan. Fitur hanya membantu membuka game dan memberikan optimasi aman.",11,MUTED,false),lp(0,18,0,0));
        setContentView(sc);
    }
    private LinearLayout stat(String title,String value,String icon){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(dp(14),dp(16),dp(14),dp(16));c.setBackground(bg(PANEL,RED,14));TextView i=text(icon,24,RED,true);c.addView(i);c.addView(text(title,14,WHITE,true),lp(0,8,0,3));c.addView(text(value,11,MUTED,false));return c;}
    private void tip(LinearLayout root,String n,String title,String desc){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(dp(15),dp(13),dp(15),dp(13));c.setBackground(bg(PANEL,Color.rgb(48,48,58),12));c.addView(text(n+"   /   "+title,14,RED,true));c.addView(text(desc,13,WHITE,false),lp(0,6,0,0));root.addView(c,lp(0,0,0,9));}
    private TextView button(String s,int color,int fg,int size){TextView t=text(s,size,fg,true);t.setGravity(Gravity.CENTER);t.setPadding(dp(12),dp(17),dp(12),dp(17));t.setBackground(bg(color,RED,16));return t;}
    private TextView cardText(String s,int size,int fg,boolean bold){TextView t=text(s,size,fg,bold);t.setPadding(dp(16),dp(17),dp(16),dp(17));t.setBackground(bg(PANEL,Color.rgb(35,75,45),14));return t;}
    private TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private GradientDrawable bg(int color,int stroke,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));d.setStroke(dp(1),stroke);return d;}
    private LinearLayout.LayoutParams lp(int l,int t,int r,int b){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(dp(l),dp(t),dp(r),dp(b));return p;}
    private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private void openMl(){Intent i=getPackageManager().getLaunchIntentForPackage("com.mobile.legends");if(i!=null)startActivity(i);else Toast.makeText(this,"Mobile Legends belum terdeteksi.",Toast.LENGTH_SHORT).show();}
}
