# AZKA GAME BOOSTER
Simple Android starter project with a dark red gaming UI, optimization checklist, and Mobile Legends launch shortcut.

## Build
1. Open this folder in Android Studio.
2. Allow Gradle sync and install Android SDK 35 if prompted.
3. Select Build > Build APK(s).

This app does not modify MLBB files, bypass protections, or promise a measurable FPS increase. Android does not allow ordinary apps to force-close other apps or directly change another game's performance settings.
